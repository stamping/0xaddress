# 0xAddress - Chrome Web Store Listing

## Nombre de la extensión
0xAddress Wallet

## Descripción corta (132 caracteres máx)
Secure self-custody Ethereum wallet. Connect to dApps, sign transactions, and manage your crypto across 20+ networks.

## Descripción completa

🔐 **0xAddress** is a secure, self-custody Ethereum wallet extension that puts you in full control of your digital assets.

### 🌟 Key Features

**🔒 Security First**
• Your private keys are encrypted locally with PBKDF2 + AES-256
• Never stored on external servers - true self-custody
• Export your wallet as an encrypted .PEM certificate for backup
• Session lock with customizable timeout (15 min to 7 days)

**🌐 Multi-Network Support**
Connect to 20+ blockchain networks including:
• Ethereum, Polygon, BNB Chain, Arbitrum, Optimism, Base
• Rollux, Syscoin, Avalanche, Fantom, and more
• Add custom networks from any dApp

**💼 Complete Wallet Management**
• Create new wallets or import from seed phrase
• View balances for native tokens and ERC-20 tokens
• Manage NFTs (ERC-721)
• Track multiple custom tokens and contracts

**🔗 Seamless dApp Integration**
• Connect to any Web3 dApp with one click
• Sign messages (personal_sign, EIP-712)
• Approve and send transactions
• Switch networks directly from dApps (EIP-3326)
• Add new networks from dApps (EIP-3085)

**🎨 User Experience**
• Clean, modern interface
• Dark and light mode support
• Available in English and Spanish
• Interactive onboarding tutorial

### 🛡️ Privacy & Security

0xAddress is designed with privacy in mind:
• No tracking or analytics
• No external API calls except to blockchain nodes
• All encryption happens locally in your browser
• Open source and auditable

### 🚀 Getting Started

1. Install the extension
2. Create a new wallet or import an existing one
3. Set a strong password
4. Start connecting to your favorite dApps!

### ⚠️ Important

This is a self-custody wallet. You are responsible for:
• Keeping your password safe
• Backing up your seed phrase or .PEM certificate
• Never sharing your private keys

For high-value assets, we recommend using a hardware wallet.

---

**Built with ❤️ for the Web3 community**

Website: https://0xaddress.com
Support: support@0xaddress.com

---

## Categoría
Productivity (o Developer Tools)

## Idioma
English, Spanish

## Tags/Keywords
- ethereum wallet
- crypto wallet
- web3
- defi
- blockchain
- metamask alternative
- self custody
- erc20
- nft
- dapp browser

## Screenshots necesarios (1280x800 o 640x400)

1. **Main wallet view** - Mostrando balance y tokens
2. **Connect to dApp** - Modal de conexión
3. **Sign transaction** - Aprobación de transacción
4. **Network selector** - Lista de redes disponibles
5. **Settings/Preferences** - Panel de configuración

## Icono
- 128x128 PNG (ya incluido en /icons/icon128.png)

## Tile promocional (440x280) - Opcional
Texto sugerido: "Your keys, your crypto. 0xAddress - Secure Web3 Wallet"

## Marquee (1400x560) - Opcional
Para featured placement

---

## Políticas de privacidad (URL requerida)
https://0xaddress.com/privacy

## Términos de servicio (URL requerida)  
https://0xaddress.com/terms
